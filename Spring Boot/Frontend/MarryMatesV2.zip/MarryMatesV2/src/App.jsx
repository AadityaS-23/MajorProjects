// import { BrowserRouter  } from "react-router-dom"
// import  NavigationBar  from "./Components/NavigationBar"
// import { AppRouter } from "./Components/AppRouter"
// import Footer from "./Components/Footer"
// import 'bootstrap/dist/js/bootstrap.bundle.min'
// import 'bootstrap/dist/css/bootstrap.min.css';
// import { NavbarProvider } from "./contexts/NavbarContext"




// function App() {
//   return (
 
//     <BrowserRouter>
//       <NavigationBar/>
//       <AppRouter/>
//       <Footer/>
//     </BrowserRouter>

//   )
// }

// export default App
import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import { NavbarProvider } from './contexts/NavbarContext';
import NavigationBar from './Components/NavigationBar';
import Home from './Components/Home';
import Services from './Components/ServicesPage';
import Signup from './Components/Signup';
import Login from './Components/Login';
import Venues from './Components/Venues';
import Vendors from './Components/Vendors';
import Aboutus from './Components/AboutUs';
import ClientsFeedback from './Components/ClientsFeedback';
import ClientSignup from './Components/ClientSignup';
import VendorSignup from './Components/VendorSignup';
import Admin from './admin/Admin';
import AdminVendors from './admin/AdminVendors';
import AdminVenues from './admin/AdminVenues';
import AdminBookings from './admin/AdminBookings';
import AdminClient from './admin/AdminClients';
import AdminReports from './admin/AdminReports';
import Gallery from './Components/Gallery';
import Vendor from './Vendor/Vendor';
import Vendorprofile from './Vendor/Vendorprofile';
import VendorBookings from './Vendor/VendorBookings';
import VendorServices from './Vendor/VendorServices';
import VendorBills from './Vendor/VendorBills';
import Client from './Client/Client';
import ClientEventDetails from './Client/ClientEventDetails';
import ClientGuestList from './Client/ClientGuestList';
import ClientManageBills from './Client/ClientManageBills';
import ClientDashboard from './Client/ClientDashboard';
import ClientProfile from './Client/ClientProfile';
import BookingSummary from './Client/BookingSummary';
import ClientFeedback from './Client/ClientFeedback';
import ResetPassword from './Components/ResetPassword';
import Footer from './Components/Footer';

function App() {
  return (
    <NavbarProvider>
      <Router>
        <NavigationBar />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/reset-password" element={<ResetPassword />} />
          <Route path="/Services" element={<Services />} />
          <Route path="/Signup" element={<Signup />} />
          <Route path="/ClientSignup" element={<ClientSignup />} />
          <Route path="/VendorSignup" element={<VendorSignup />} />
          <Route path="/Login" element={<Login />} />
          <Route path="/Vendors" element={<Vendors />} />
          <Route path="/Venues" element={<Venues />} />
          <Route path="/Aboutus" element={<Aboutus />} />
          <Route path="/ClientsFeedback" element={<ClientsFeedback />} />
          <Route path="/admin" element={<Admin />} />
          <Route path="/admin/vendors" element={<AdminVendors />} />
          <Route path="/admin/venues" element={<AdminVenues />} />
          <Route path="/admin/bookings" element={<AdminBookings />} />
          <Route path="/admin/clients" element={<AdminClient />} />
          <Route path="/admin/reports" element={<AdminReports />} />
          <Route path="/Gallery" element={<Gallery />} />
          <Route path="/Vendor" element={<Vendor />} />
          <Route path="/Vendor/Vendorprofile" element={<Vendorprofile />} />
          <Route path="/Vendor/VendorBookings" element={<VendorBookings />} />
          <Route path="/Vendor/VendorServices" element={<VendorServices />} />
          <Route path="/Vendor/VendorBills" element={<VendorBills />} />
          <Route path="/client" element={<Client />} />
          <Route path="/Client/ClientEventDetails" element={<ClientEventDetails />} />
          <Route path="/client/guestlist" element={<ClientGuestList />} />
          <Route path="/client/managebills" element={<ClientManageBills />} />
          <Route path="/Client/ClientDashboard" element={<ClientDashboard />} />
          <Route path="/Client/ClientProfile" element={<ClientProfile />} />
          <Route path="/Client/BookingSummary" element={<BookingSummary />} />
          <Route path="/Client/ClientFeedback" element={<ClientFeedback />} />
        </Routes>
        <Footer/>
      </Router>

    </NavbarProvider>
  );
}

export default App;