import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate, useSearchParams } from 'react-router-dom';

const ResetPassword = () => {
  const [newPassword, setNewPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const token = searchParams.get('token');

  const handleNewPasswordSubmit = async (e) => {
    e.preventDefault();

    if (!newPassword) {
      setError('New password is required.');
      return;
    }

    if (newPassword.length < 6) {
      setError('Password must be at least 6 characters long.');
      return;
    }

    // API call to reset password
    try {
      const response = await axios.post("http://localhost:8080/api/auth/reset-password/confirm", { token, newPassword });
      console.log("New password response:", response);
      if (response.status === 200) {
        alert('Password has been reset successfully.');
        navigate('/login');
      }
    } catch (error) {
      console.error("New password error:", error);
      if (error.response) {
        console.error("Server response:", error.response.data);
        setError(error.response.data || 'An error occurred. Please try again.');
      } else {
        setError('An error occurred. Please try again.');
      }
    }
  };

  return (
    <div className="reset-password-form">
      <h2>Reset Password</h2>
      <form onSubmit={handleNewPasswordSubmit}>
        <label>New Password</label>
        <input
          type="password"
          placeholder="Enter your new password"
          value={newPassword}
          onChange={(e) => setNewPassword(e.target.value)}
        />
        {error && <p style={{ color: 'red' }}>{error}</p>}
        <div className="button-container">
          <button type="submit">Reset Password</button>
        </div>
      </form>
    </div>
  );
};

export default ResetPassword;